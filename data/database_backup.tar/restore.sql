--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.2
-- Dumped by pg_dump version 14.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE basketball;
--
-- Name: basketball; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE basketball WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'English_United States.1252';


ALTER DATABASE basketball OWNER TO postgres;

\connect basketball

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: arenas; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.arenas (
    arena_pk character varying(255) NOT NULL,
    latitude real NOT NULL,
    longitude real NOT NULL,
    arena character varying(255) NOT NULL,
    team character varying(255) NOT NULL,
    sector character varying(255) NOT NULL,
    subsector character varying(255)
);


ALTER TABLE public.arenas OWNER TO postgres;

--
-- Name: draft; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.draft (
    yeardraft real NOT NULL,
    numberpickoverall integer NOT NULL,
    numberround integer NOT NULL,
    numberroundpick integer NOT NULL,
    nameplayer character varying(255) NOT NULL,
    slugteam character varying(255) NOT NULL,
    nameorganizationfrom character varying(255),
    typeorganizationfrom character varying(255),
    idplayer real NOT NULL,
    idteam real,
    nameteam character varying(255) NOT NULL,
    cityteam character varying(255) NOT NULL,
    teamname character varying(255) NOT NULL,
    player_profile_flag integer,
    slugorganizationtypefrom character varying(255),
    locationorganizationfrom character varying(255)
);


ALTER TABLE public.draft OWNER TO postgres;

--
-- Name: player_2020_salaries; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.player_2020_salaries (
    rank integer NOT NULL,
    idplayer real,
    team character varying(255) NOT NULL,
    player character varying(255) NOT NULL,
    salary real NOT NULL
);


ALTER TABLE public.player_2020_salaries OWNER TO postgres;

--
-- Name: team_attributes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.team_attributes (
    id integer NOT NULL,
    abbreviation character varying(5) NOT NULL,
    nickname character varying(255) NOT NULL,
    yearfounded real NOT NULL,
    city character varying(255) NOT NULL,
    arena character varying(255) NOT NULL,
    arenacapacity real,
    owner character varying(255) NOT NULL,
    generalmanager character varying(255) NOT NULL,
    headcoach character varying(255) NOT NULL,
    dleagueaffiliation character varying(255) NOT NULL,
    facebook_website_link character varying(255) NOT NULL,
    instagram_website_link character varying(255) NOT NULL,
    twitter_website_link character varying(255) NOT NULL
);


ALTER TABLE public.team_attributes OWNER TO postgres;

--
-- Name: win_counts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.win_counts (
    team character varying(255) NOT NULL,
    division character varying(255) NOT NULL,
    conference character varying(255) NOT NULL,
    win_count integer NOT NULL
);


ALTER TABLE public.win_counts OWNER TO postgres;

--
-- Data for Name: arenas; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.arenas (arena_pk, latitude, longitude, arena, team, sector, subsector) FROM stdin;
\.
COPY public.arenas (arena_pk, latitude, longitude, arena, team, sector, subsector) FROM '$$PATH$$/3333.dat';

--
-- Data for Name: draft; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.draft (yeardraft, numberpickoverall, numberround, numberroundpick, nameplayer, slugteam, nameorganizationfrom, typeorganizationfrom, idplayer, idteam, nameteam, cityteam, teamname, player_profile_flag, slugorganizationtypefrom, locationorganizationfrom) FROM stdin;
\.
COPY public.draft (yeardraft, numberpickoverall, numberround, numberroundpick, nameplayer, slugteam, nameorganizationfrom, typeorganizationfrom, idplayer, idteam, nameteam, cityteam, teamname, player_profile_flag, slugorganizationtypefrom, locationorganizationfrom) FROM '$$PATH$$/3329.dat';

--
-- Data for Name: player_2020_salaries; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.player_2020_salaries (rank, idplayer, team, player, salary) FROM stdin;
\.
COPY public.player_2020_salaries (rank, idplayer, team, player, salary) FROM '$$PATH$$/3331.dat';

--
-- Data for Name: team_attributes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.team_attributes (id, abbreviation, nickname, yearfounded, city, arena, arenacapacity, owner, generalmanager, headcoach, dleagueaffiliation, facebook_website_link, instagram_website_link, twitter_website_link) FROM stdin;
\.
COPY public.team_attributes (id, abbreviation, nickname, yearfounded, city, arena, arenacapacity, owner, generalmanager, headcoach, dleagueaffiliation, facebook_website_link, instagram_website_link, twitter_website_link) FROM '$$PATH$$/3332.dat';

--
-- Data for Name: win_counts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.win_counts (team, division, conference, win_count) FROM stdin;
\.
COPY public.win_counts (team, division, conference, win_count) FROM '$$PATH$$/3330.dat';

--
-- Name: arenas arenas_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.arenas
    ADD CONSTRAINT arenas_pkey PRIMARY KEY (arena_pk);


--
-- Name: draft draft_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.draft
    ADD CONSTRAINT draft_pkey PRIMARY KEY (idplayer);


--
-- Name: player_2020_salaries player_2020_salaries_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.player_2020_salaries
    ADD CONSTRAINT player_2020_salaries_pkey PRIMARY KEY (rank);


--
-- Name: team_attributes team_attributes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.team_attributes
    ADD CONSTRAINT team_attributes_pkey PRIMARY KEY (id);


--
-- Name: win_counts win_counts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.win_counts
    ADD CONSTRAINT win_counts_pkey PRIMARY KEY (team);


--
-- Name: player_2020_salaries player_2020_salaries_idplayer_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.player_2020_salaries
    ADD CONSTRAINT player_2020_salaries_idplayer_fkey FOREIGN KEY (idplayer) REFERENCES public.draft(idplayer);


--
-- PostgreSQL database dump complete
--

